<?php
session_start();
include_once('connect_db.php');
if(isset($_SESSION['username'])){
$id=$_SESSION['pharmacist_id'];
$user=$_SESSION['username'];
}else{
header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."index.php");
exit();
}
if(isset($_POST['submit'])){
$sname=$_POST['drug_name'];
$cat=$_POST['category'];
$des=$_POST['description'];
$com=$_POST['company'];
$sup=$_POST['supplier'];
$qua=$_POST['quantity'];
$cost=$_POST['cost'];
$sta="Available";

$sql=mysqli_query($con,"INSERT INTO stock(drug_name,category,description,company,supplier,quantity,cost,status,date_supplied)
VALUES('$sname','$cat','$des','$com','$sup','$qua','$cost','$sta',NOW())");
if($sql>0) {header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/stock.php");
}else{
$message1="<font color=red>Registration Failed, Try again</font>";
}
	}
?>	
<!doctype html>
<html lang="en-US">

	<head>
	   <meta charset="utf-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		<title>Pharmacy Management</title>
		<link rel="icon" href="images/download.PNG" type="image/png"/> <!--adding an icon to tab -->
		<!-- Bootstrap -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<script src="js1/jquery.min.js"></script>
		<script src="js1/bootstrap.min.js"></script>
		<link rel="stylesheet" type="text/css" href="css/styleforP.css"/> <!-- linking stylesheet-->
		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	
	
	</head>
	
	<body id="wrapper">
	
		<div class="jumbotron jumbo">
			<h2>Pharmacy Management System</h2> 
		</div>
		
		<div class="container-fluid stoppad">
			<div class="row">
			<div class="col-md-2 sidenav">
				<ul class="nav nav-pills nav-stacked">
					<li><a href="pharmacist.php">Dashboard</a></li>
					<li><a href="prescription.php">prescription</a></li>
					<li class="active"><a href="stock.php">Stock</a></li>
					<li><a href="logout.php">Log out</a></li>
				</ul>
			</div>
			
			<div class="col-md-10">
				<h3 class="manage">Manage Stocks</h3>
			<hr>
				<div class="container-fluid">
					  <ul class="nav nav-tabs">
						<li class="active"><a data-toggle="tab" href="#view">View Stock</a></li>
						<li><a data-toggle="tab" href="#add">Add New Drug</a></li>
					</ul>
					
					<div class="tab-content">
					
					
						<div id="view" class="tab-pane fade in active">
								 <?php echo $message;
									echo $message1;
								 ?>
      
							<?php
							/*View Displays all data from 'manager' table*/
							// connect to the database
								include_once('connect_db.php');
									// get results from database
							$result = mysqli_query($con,"SELECT * FROM stock") 
									or die(mysql_error());
								// display data in table
								
							echo "<table class='table table-striped'>
							
								<thead>
									<tr><th>Name</th><th>Category</th><th>Description</th><th>Status </th><th>Date </th><th>Delete</th></tr>
								</thead>"; 
								        // loop through results of database query, displaying them in the table
								while($row = mysqli_fetch_array( $result )) {
								// echo out the contents of each row into a table
									echo "<tbody>";
									echo "<tr>";              
									echo '<td>' . $row['drug_name'] . '</td>';
									echo '<td>' . $row['category'] . '</td>';
									echo '<td>' . $row['description'] . '</td>';
									echo '<td>' . $row['status'] . '</td>';
									echo '<td>' . $row['date_supplied'] . '</td>';
								?>
							
								<td><a href="delete_stock.php?stock_id=<?php echo $row['stock_id']?>"><span class="glyphicon glyphicon-remove"style="color:red;"></span></a></td>
								<?php
								}
								echo "</tbody>";
								echo "</table>";
							?>
						</div>
						
						<div id="add" class="tab-pane fade">
						<!--Pharmacist-->
								<?php echo $message;
								echo $message1;
								?>
							<form class="form form-horizontal" role="form" name="form1" action="stock.php" method="POST" >
							
								<div class="form-group">
									<label class="control-label col-sm-2" for="Drug name">Drug Name:</label>
									<div class="col-sm-10">
									<input class="form-control" name="drug_name" type="text"  placeholder="drug name" required id="drug_name" />
									</div>
								</div>

								<div class="form-group">
									<label class="control-label col-sm-2" for="Last name">Category:</label>
									<div class="col-sm-10">
									<input class="form-control" name="category" type="text"  placeholder="category" required id="category" />
									</div>
								</div>

								<div class="form-group">
									<label class="control-label col-sm-2" for="description">Description:</label>
									<div class="col-sm-10">
									<input class="form-control" name="description" type="text"  placeholder="description" required id="description" />
									</div>
									
								</div>

								<div class="form-group">
									<label class="control-label col-sm-2" for="company">Company:</label>
									<div class="col-sm-10">
									<input class="form-control" name="company" type="text"  placeholder="Manufacturing Company" required id="company" />
									</div>
								</div>

								<div class="form-group">
									<label class="control-label col-sm-2" for="supplier">Supplier:</label>
									<div class="col-sm-10">
									<input class="form-control" name="supplier" type="text" placeholder="supplier"  required id="supplier" />  
									</div>
								</div>

								<div class="form-group">
									<label class="control-label col-sm-2" for="quantity">quantity:</label>
									<div class="col-sm-10">
									<input class="form-control" name="quantity" type="text" placeholder="Quantity" required id="quantity" /> 
									</div>
								</div>

							
								<div class="form-group">
									<label class="control-label col-sm-2" for="cost">Unit Cost:</label>
									<div class="col-sm-10">
									<input class="form-control" name="cost" type="number"  placeholder="Unit Cost" required id="cost"/>
									</div>
								</div>								
								
								<div class="col-sm-2"></div>
								<div class="col-sm-offset-2 col-sm-6">
								<button class="btn btn-primary btn-block btn-lg" name="submit" type="submit" >submit</button>
								</div>
							</form>
						
						
						</div>
						
						
					</div>
				
				</div>
			</div>
			</div>
			
			
			
		</div>
		
		
		
		
		<div id="footer">
		
			</div>
	</body>
	

	
</html>