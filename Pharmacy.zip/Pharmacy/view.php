<?php
session_start();
include_once('connect_db.php');
if(isset($_SESSION['username'])){
$id=$_SESSION['manager_id'];
$fname=$_SESSION['first_name'];
$lname=$_SESSION['last_name'];
$sid=$_SESSION['staff_id'];
$user=$_SESSION['username'];
}else{
header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/index.php");
exit();
}
?>

<!doctype html>
<html>

	<head>
	   <meta charset="utf-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		<title>Pharmacy Management</title>
		<link rel="icon" href="images/download.PNG" type="image/png"/> <!--adding an icon to tab -->
		<!-- Bootstrap -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link rel="stylesheet" type="text/css" href="css/styleforP.css"/> <!-- linking stylesheet-->
		<script src="js1/jquery.min.js"></script>
		<script src="js1/bootstrap.min.js"></script>
		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	
	
	</head>
	
	<body id="wrapper">
	
		<div class="jumbotron jumbo">
			<h2>Pharmacy Management System</h2> 
		</div>
		
		<div class="container-fluid stoppad">
			<div class="row">
			<div class="col-md-2 sidenav">
				<ul class="nav nav-pills nav-stacked">
					<li ><a href="manager.php">Dashboard</a></li>
					<li class="active"><a href="view.php">View Users</a></li>
					<li><a href="view_prescription.php">View Prescriptions</a></li>
					<li><a href="stock.php">Manage Stock</a></li>
					<li><a href="logout.php">Log out</a></li>
				</ul>
			</div>
			
			<div class="col-md-10">
			
				<div class="col-md-10">
				<h3 class="manage">View Staff Details</h3>
			<hr>
			
			<div class="container-fluid">
					  <ul class="nav nav-tabs">
						<li class="active"><a data-toggle="tab" href="#viewPharmacist">Pharmacists</a></li>
						<li ><a data-toggle="tab" href="#viewCashier">Cashiers</a></li>
						<li ><a data-toggle="tab" href="#viewManager">Managers</a></li>
					</ul>
					
					<div class="tab-content">
					
					
						<div id="viewPharmacist" class="tab-pane fade in active">
							<?php echo $message1; echo $message;
								  
								/*View Displays all data from 'prescription' table*/
								// connect to the database
									include_once('connect_db.php');
										// get results from database
								$result = mysqli_query($con,"SELECT * FROM pharmacist")or die(mysqli_error());	
								echo "<table class='table table-striped'>
								
									<thead>
										<tr><th>Firstname</th> <th>Lastname </th><th>Username </th><th>Phone</th><th>Email</th></tr>
									</thead>"; 
											// loop through results of database query, displaying them in the table
									while($row = mysqli_fetch_array( $result )) {
										// echo out the contents of each row into a table
										echo "<tbody>";
										echo "<tr>";
										echo '<td>' . $row['first_name'] . '</td>';
										echo '<td>' . $row['last_name'] . '</td>';
										echo '<td>' . $row['username'] . '</td>';
										echo '<td>' . $row['phone'] . '</td>';
										echo '<td>' . $row['email'] . '</td>';
									}
										echo "</tbody>";
										echo "</table>";
								?>
						</div>
						
						<div id="viewCashier" class="tab-pane fade ">
							<?php echo $message1; echo $message;
								  
								/*View Displays all data from 'prescription' table*/
								// connect to the database
									include_once('connect_db.php');
										// get results from database
								$result = mysqli_query($con,"SELECT * FROM cashier")or die(mysqli_error());	
								echo "<table class='table table-striped'>
								
									<thead>
										<tr><th>Firstname</th> <th>Lastname </th><th>Username </th><th>Phone</th><th>Email</th></tr>
									</thead>"; 
											// loop through results of database query, displaying them in the table
									while($row = mysqli_fetch_array( $result )) {
										// echo out the contents of each row into a table
										echo "<tbody>";
										echo "<tr>";
										echo '<td>' . $row['first_name'] . '</td>';
										echo '<td>' . $row['last_name'] . '</td>';
										echo '<td>' . $row['username'] . '</td>';
										echo '<td>' . $row['phone'] . '</td>';
										echo '<td>' . $row['email'] . '</td>';
									}
										echo "</tbody>";
										echo "</table>";
								?>
						
						</div>
						
						<div id="viewManager" class="tab-pane fade">
							<?php echo $message1; echo $message;
								  
								/*View Displays all data from 'prescription' table*/
								// connect to the database
									include_once('connect_db.php');
										// get results from database
								$result = mysqli_query($con,"SELECT * FROM manager")or die(mysqli_error());	
								echo "<table class='table table-striped'>
								
									<thead>
										<tr><th>Firstname</th> <th>Lastname </th><th>Username </th><th>Phone</th><th>Email</th></tr>
									</thead>"; 
											// loop through results of database query, displaying them in the table
									while($row = mysqli_fetch_array( $result )) {
										// echo out the contents of each row into a table
										echo "<tbody>";
										echo "<tr>";
										echo '<td>' . $row['first_name'] . '</td>';
										echo '<td>' . $row['last_name'] . '</td>';
										echo '<td>' . $row['username'] . '</td>';
										echo '<td>' . $row['phone'] . '</td>';
										echo '<td>' . $row['email'] . '</td>';
									}
										echo "</tbody>";
										echo "</table>";
								?>
						</div>
				
						
						
					</div>
				
				</div>
			</div>
			</div>
			
			</div>
			
			
			
		</div>
		<div id="footer">
			</div>
	</body>
	
</html>