<?php
require_once('connect_db.php');
if(isset($_POST['pharmacist_id'])){
	$userID = $_POST['pharmacist_id'];
	$details = mysqli_fetch_assoc($con->query('SELECT * FROM pharmacist WHERE pharmacist_id='.$userID.''));
	
	echo json_encode($details);
}
?>

<?php
require_once('connect_db.php');
if(isset($_POST['manager_id'])){
	$userID = $_POST['manager_id'];
	$details = mysqli_fetch_assoc($con->query('SELECT * FROM manager WHERE manager_id='.$userID.''));
	
	echo json_encode($details);
}
?>

<?php
require_once('connect_db.php');
if(isset($_POST['cashier_id'])){
	$userID = $_POST['cashier_id'];
	$details = mysqli_fetch_assoc($con->query('SELECT * FROM cashier WHERE cashier_id='.$userID.''));
	
	echo json_encode($details);
}
?>