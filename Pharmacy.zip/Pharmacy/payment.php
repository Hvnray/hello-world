<?php
session_start();
include_once('connect_db.php');
if(isset($_SESSION['username'])){
$id=$_SESSION['cashier_id'];
$fname=$_SESSION['first_name'];
$lname=$_SESSION['last_name'];
$user=$_SESSION['username'];
}else{
header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/index.php");
exit();
}
?>

<!doctype html>
<html>

	<head>
	   <meta charset="utf-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		<title>Pharmacy Management</title>
		<link rel="icon" href="images/download.PNG" type="image/png"/> <!--adding an icon to tab -->
		<!-- Bootstrap -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link rel="stylesheet" type="text/css" href="css/styleforP.css"/> <!-- linking stylesheet-->
		<script src="js1/jquery.min.js"></script>
		<script src="js1/bootstrap.min.js"></script>
		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->


	</head>

	<body id="wrapper">

		<div class="jumbotron jumbo">
			<h2>Pharmacy Management System</h2>
		</div>

		<div class="container-fluid stoppad">
			<div class="row">
			<div class="col-md-2 sidenav">
				<ul class="nav nav-pills nav-stacked">
					<li ><a href="cashier.php">Dashboard</a></li>
					<li class="active"><a href="payment.php">Process Payment</a></li>
					<li><a href="logout.php">Log out</a></li>
				</ul>
			</div>

			<div class="col-md-10">
				<h3 class="manage">Manage Payment</h3>
				<hr>

				<div class="container-fluid">
					  <ul class="nav nav-tabs">
						<li class="active"><a data-toggle="tab" href="#process">Process Payment</a></li>
						</ul>

						<?php
							$invoice_no=$_SESSION['invoice_no'];
							$amount=$_SESSION['amount'];
							$payType=$_SESSION['payType'];
							$serial_no=$_SESSION['serial_no'];

						?>

					<div class="tab-content">


						<div id="process" class="tab-pane fade in active">

							<form class="form form-horizontal" role="form" name="myform" action="receipt.php" method="POST" >
								<br />
								<div class="form-group">
									<label class="control-label col-sm-2" for="invoice Number">invoice No:</label>
									<div class="col-sm-8">
									<input class="form-control" name="invoice_no" type="text"  placeholder="invoice No" required id="invoice_no" />
									</div>
								</div>

								<div class="form-group">
									<label class="control-label col-sm-2" for="Amount">Amount:</label>
									<div class="col-sm-8">
									<input class="form-control" name="amount" type="text"  placeholder="Amount" required id="amount" />
									</div>
								</div>

								<div class="form-group">
									<label class="control-label col-sm-2" for="username">Payment Type:</label>
									<div class="col-sm-8">
									<?php
										echo"<select  class='form-control' name='payType' id='payment_type'>";
												 $getpayType=mysqli_query($con,"SELECT Name FROM paymentTypes");
												 echo"<option>Select Payment</option>";
											while($pType=mysqli_fetch_array($getpayType)){
										echo"<option>".$pType['Name']."</option>";
									}

									echo"</select>";
									?>
									</div>

								</div>

								<div class="form-group">
									<label class="control-label col-sm-2" for="Serial No">Serial No:</label>
									<div class="col-sm-8">
									<input class="form-control" name="serial_no" type="text"  placeholder="Serial No" required id="serial_no"/>
									</div>
								</div>

								<div class="col-sm-2"></div>
								<div class="col-sm-6">
								<button class="btn btn-primary btn-block btn-lg" name="tuma" id="tuma" type="submit" >submit</button>
								</div>
							</form>

						</div>


					</div>

				</div>
			</div>
			</div>



		</div>
		<div id="footer">
		</div>

<script>
	$(document).ready(function(){
		$("#invoice_no").change(function(){
			var invoice_no=$("#invoice_no").val();

			if(invoice_no.length >0){
				$.ajax({
					type: "POST",
					url: "check.php",
					data: 'invoice_no='+invoice_no ,
					success: function(msg){
						$("#viewer2").ajaxComplete(function(event, request, settings){
							if(msg){
								$(this).html(msg);

							}else{
								$(this).html('<font color="red"><strong>Invoice does not exist</strong></font>');
							}


						});
					}
				});
				}
	});
	});

</script>
	</body>

</html>
