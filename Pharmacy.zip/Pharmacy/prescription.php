<?php
session_start();
include_once('connect_db.php');
if(isset($_SESSION['username'])){
$id=$_SESSION['pharmacist_id'];
$fname=$_SESSION['first_name'];
$lname=$_SESSION['last_name'];
$sid=$_SESSION['staff_id'];
$user=$_SESSION['username'];
}else{
header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/index.php");
exit();
}

if(isset($_POST['submit'])){
$c_name=$_POST['customer_name'];
$age=$_POST['age'];
$sex=$_POST['sex'];
$address=$_POST['postal_address'];
$phone=$_POST['phone'];
$drug=$_POST['drug_name'];
$cost=$_POST['cost'];
$dose=$_POST['dose'];
$quantity=$_POST['quantity'];


$sql=mysqli_query($con,"INSERT INTO prescription(customer_name,age,sex,postal_address,phone,date)
VALUES('$c_name','$age','$sex','$address','$phone',NOW())");
var_dump("INSERT INTO prescription(customer_name,age,sex,postal_address,phone,date)
VALUES('$c_name','$age','$sex','$address','$phone',NOW())");
if($sql>0) {header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/stock_pharmacist.php");
}else{
$message1="<font color=red>Registration Failed, Try again</font>";
}
	}
?>

<!doctype html>
<html>

	<head>
	   <meta charset="utf-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		<title>Pharmacy Management</title>
		<link rel="icon" href="images/download.PNG" type="image/png"/> <!--adding an icon to tab -->
		<!-- Bootstrap -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link rel="stylesheet" type="text/css" href="css/styleforP.css"/> <!-- linking stylesheet-->
		<script src="js1/jquery.min.js"></script>
		<script src="js1/bootstrap.min.js"></script>
		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>

	  <![endif]-->

  	</head>

	<body id="wrapper">

		<div class="jumbotron jumbo">
			<h2>Pharmacy Management System</h2>
		</div>

		<div class="container-fluid stoppad">
			<div class="row">
			<div class="col-md-2 sidenav">
				<ul class="nav nav-pills nav-stacked">
					<li><a href="pharmacist.php">Dashboard</a></li>
					<li class="active"><a href="prescription.php">Prescription</a></li>
					<li><a href="stock.php">Stock</a></li>
					<li><a href="logout.php">Log out</a></li>
				</ul>
			</div>

			<div class="col-md-10">
				<h3 class="manage">Manage Prescriptions</h3>
			<hr>

			<div class="container-fluid">
					  <ul class="nav nav-tabs">
						<li class="active"><a data-toggle="tab" href="#view">View Prescriptions</a></li>
						<li ><a data-toggle="tab" href="#add">Create New Prescription</a></li>
					</ul>

					<div class="tab-content">


						<div id="view" class="tab-pane fade in active">
						<?php echo $message1;

							/*View Displays all data from 'prescription' table*/
							// connect to the database
								include_once('connect_db.php');
									// get results from database
							$result = mysqli_query($con,"SELECT * FROM prescription")or die(mysqli_error());
							echo "<table class='table table-striped'>

								<thead>
									<tr> <th>Customer</th><th>Prescription N<sup>o</sup></th> <th>Invoice N<sup>o</sup></th><th>Date </th><th>Delete</th></tr>
								</thead>";
								        // loop through results of database query, displaying them in the table
								while($row = mysqli_fetch_array( $result )) {
								// echo out the contents of each row into a table
								echo "<tbody>";
								echo "<tr>";
								//echo '<td>' . $row['pharmacist_id'] . '</td>';
							    echo '<td>' . $row['customer_name'] . '</td>';
								echo '<td>' . $row['prescription_id'] . '</td>';
								echo '<td>' . $row['invoice_id'] . '</td>';
								echo '<td>' . $row['date'] . '</td>';
								?>
								<td><a href="delete_prescription.php?prescription_id=<?php echo $row['prescription_id']?>"><span class="glyphicon glyphicon-remove"style="color:red;"></span></a></td>
								<?php
								}
								echo "</tbody>";
								echo "</table>";
							?>
						</div>

						<div id="add" class="tab-pane fade">


						<!--Pharmacist-->
						<?php
						$invNum= mysqli_query ($con,"SELECT 1+MAX(invoice_id) FROM invoice");
						$invoice=mysqli_fetch_array($invNum);
						if($invoice[0]=='')
						{$invoiceNo=10; }
						else{$invoiceNo=$invoice[0];}
						$_SESSION['invoice']=$invoiceNo;

						?>
						    <!--Pharmacist-->
							<?php echo $message;
							  echo $message1;
							 ?><br />
							<form class="form form-horizontal" role="form" name="myform"  action="invoice.php" method="POST" >

								<div class="form-group">
									<label class="control-label col-sm-2" for="customer name">Customer Name:</label>
									<div class="col-sm-10">
									<input class="form-control" name="customer_name" type="text"  placeholder="customer name" required id="customer_name" />
									</div>
								</div>

								<div class="form-group">
									<label class="control-label col-sm-2" for="age">Age:</label>
									<div class="col-sm-4">
									<input class="form-control" name="age" type="text"  placeholder="age" required id="age" />
									</div>

									<label class="control-label col-sm-1" for="sex">Sex:</label>
									<div class="col-sm-5">
									<input class="form-control" name="sex" type="text"  placeholder="Gender" required id="sex" />
									</div>

								</div>

								<div class="form-group">
									<label class="control-label col-sm-2" for="address">Address:</label>
									<div class="col-sm-10">
									<input class="form-control" name="postal_address" type="text"  placeholder="Address" required id="postal_address" />
									</div>
								</div>

								<div class="form-group">
									<label class="control-label col-sm-2" for="phone number">Phone Number:</label>
									<div class="col-sm-10">
									<input class="form-control" name="phone" type="number" placeholder="Phone"  required id="phone" />
									</div>
								</div>

								<div class="form-group">
									<label class="control-label col-sm-2" for="drug Name">Drug Name:</label>
									<div class="col-sm-10">
										<?php
											echo"<select  class='form-control' name='drug_name' id='drug_name'>";
														$getpayType=mysqli_query($con,"SELECT drug_name FROM stock");
													 echo"<option>Select Drug</option>";
												while($pType=mysqli_fetch_array($getpayType)){
													echo"<option>".$pType['drug_name']."</option>";
												}
											echo"</select>";?>

									</div>
								</div>


								<div class="form-group">
									<label class="control-label col-sm-2" for="dose">Dose (Mg):</label>
									<div class="col-sm-10">
									<input class="form-control" name="dose" type="number"  placeholder="dose" required id="dose"/>
									</div>
								</div>

								<div class="form-group">
									<label class="control-label col-sm-2" for="dose">Quantity:</label>
									<div class="col-sm-10">
									<input class="form-control" name="Quantity" type="number"  placeholder="Quantity" required id="Quantity"/>
									</div>
								</div>

								<div class="col-sm-2"></div>
								<div class="col-sm-offset-2 col-sm-6">
								<button class="btn btn-primary btn-block btn-lg" name="submit" type="submit" >submit</button>
								</div>
							</form>


						</div>


					</div>

				</div>
			</div>
			</div>



		</div>
		<div id="footer">
			</div>
				<script>


					document.getElementById('drug_name').selectedIndex = 0;

								$(document).ready(function(){
									$("#drug_name,#strength,#dose,#quantity").change(function(){

										var drug_name=$("#drug_name").val();
										var strength=$("#strength").val();
										var dose=$("#dose").val();
										var quantity=$("#quantity").val();

										if(drug_name.length && strength.length && dose.length && quantity.length>0 ){
											$.ajax({
												type: "POST",
												url: "check.php",
												data: 'drug_name='+drug_name +'&strength='+strength+'&dose='+dose +'&quantity='+quantity,
												success: function(msg){
													$("#viewer2").ajaxComplete(function(event, request, settings){
														if(msg != ''){
															$(this).html(msg);
															$('#strength, #dose, #quantity').val('');
															document.getElementById('drug_name').selectedIndex = 0;
														}
													});
												}
											});
										}
									});

									$("#customer_id,#customer_name,#age,#sex,#postal_address,#phone").change(function()
									{
										var customer_id=$("#customer_id").val();
										var customer_name=$("#customer_name").val();
										var age=$("#age").val();
										var sex=$("#sex").val();
										var postal_address=$("#postal_address").val();
										var phone=$("#phone").val();

										if(customer_id.length && customer_name.length && age.length && sex.length && postal_address.length && phone.length >0){
											$.ajax({
												type: "POST",
												url: "check.php",
												data: 'customer_id='+customer_id +'&customer_name='+customer_name +'&age='+age +'&sex='+sex +'&postal_address='+postal_address +'&phone='+phone,
												success: function(msg){
												$("#viewer2").ajaxComplete(function(event, request, settings){

													if(msg != ''){

																}
													});
												}
											});
										}
								});
							});

				</script>


	</body>

</html>
