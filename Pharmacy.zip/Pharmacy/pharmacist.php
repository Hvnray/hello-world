<?php
session_start();
include_once('connect_db.php');
if(isset($_SESSION['username'])){
$id=$_SESSION['pharmacist_id'];
$fname=$_SESSION['first_name'];
$lname=$_SESSION['last_name'];
$user=$_SESSION['username'];
}else{
header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/index.php");
exit();
}
?>

<!doctype html>
<html>

	<head>
	   <meta charset="utf-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		<title>Pharmacy Management</title>
		<link rel="icon" href="images/download.PNG" type="image/png"/> <!--adding an icon to tab -->
		<!-- Bootstrap -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link rel="stylesheet" type="text/css" href="css/styleforP.css"/> <!-- linking stylesheet-->
		<script src="js1/jquery.min.js"></script>
		<script src="js1/bootstrap.min.js"></script>
		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->


	</head>

	<body id="wrapper">

		<div class="jumbotron jumbo">
			<h2>Pharmacy Management System</h2>
		</div>

		<div class="container-fluid stoppad">
			<div class="row">
				<div class="col-md-2 sidenav">
					<ul class="nav nav-pills nav-stacked">
						<li class="active"><a href="pharmacist.php">Dashboard</a></li>
						<li><a href="prescription.php">Prescription</a></li>
						<li><a href="stock.php">Stock</a></li>
						<li><a href="logout.php">Log out</a></li>
					</ul>
				</div>

				<div class="col-md-10">
					<h3 class="manage">DASHBOARD</h3>
					<hr>


								<div class="container" style="overflow-y: scroll; height:28em;">

									<form class="form form-horizontal" role="form" method="POST" id="comment_form">
											<br/>
										<div class="form-group">
													<label class="control-label col-sm-2" for="username"><input type="text" name="comment_name" id="comment_name" class="form-control" placeholder="Enter Name" value="<?php echo $fname,' ', $lname; ?>" readonly /></label>

												<div class="col-sm-8">
													 <textarea name="comment_content" id="comment_content" class="form-control" placeholder="Enter Comment" rows="3"></textarea>

													 <input type="hidden" name="comment_id" id="comment_id" value="0" />
													 <br/>
													 <input type="submit" name="submit" id="submit" class="btn btn-info" value="Submit" />
												</div>
										</div>
									</form>

										   <span id="comment_message"></span>
										   <br />
										   <div id="display_comment"></div>

								</div>

				</div>
				</div>
			</div>



		</div>
		<div id="footer"></div>
<script>
				$(document).ready(function(){

				 $('#comment_form').on('submit', function(event){
				  event.preventDefault();
				  var form_data = $(this).serialize();
				  $.ajax({
				   url:"add_comment.php",
				   method:"POST",
				   data:form_data,
				   dataType:"JSON",
				   success:function(data)
				   {
					if(data.error != '')
					{
					 $('#comment_form')[0].reset();
					 $('#comment_message').html(data.error);
					 $('#comment_id').val('0');
					 load_comment();
					}
				   }
				  })
				 });

				 load_comment();

				 function load_comment()
				 {
				  $.ajax({
				   url:"fetch_comment.php",
				   method:"POST",
				   success:function(data)
				   {
					$('#display_comment').html(data);
				   }
				  })
				 }

				 $(document).on('click', '.reply', function(){
				  var comment_id = $(this).attr("id");
				  $('#comment_id').val(comment_id);
				  $('#comment_name').focus();
				 });

				});
</script>
		</body>

</html>
