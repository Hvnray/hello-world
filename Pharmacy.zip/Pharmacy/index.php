<?php
include_once 'connect_db.php';
if(isset($_POST['submit'])){
$username=trim($_POST['username']);
$password=$_POST['password'];
$position=$_POST['position'];
$message='<div class="alert alert-danger" style="margin-bottom:0;height:2em;padding-top:0;"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Invalid login Try Again</div>';

switch($position){
	case 'Admin':
		$result=mysqli_query($con, "SELECT admin_id, username FROM admin WHERE username='$username' AND password='$password'");
		$row=mysqli_fetch_array($result);
		if($row>0){
			session_start();
			$_SESSION['admin_id']=$row[0];
			$_SESSION['username']=$row[1];
			header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/admin.php");
		}else{
			$message;
}
break;
	case 'Pharmacist':
		$result=mysqli_query($con,"SELECT pharmacist_id, first_name, last_name, username FROM pharmacist WHERE username='$username' AND password='$password'");
		$row=mysqli_fetch_array($result);
		if($row>0){
			session_start();
			$_SESSION['pharmacist_id']=$row[0];
			$_SESSION['first_name']=$row[1];
			$_SESSION['last_name']=$row[2];
			$_SESSION['username']=$row[3];
			header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/pharmacist.php");
		}else{
			$message;
}
break;
	case 'Cashier':
		$result=mysqli_query($con,"SELECT cashier_id, first_name,last_name, username FROM cashier WHERE username='$username' AND password='$password'");
		$row=mysqli_fetch_array($result);
		if($row>0){
			session_start();
			$_SESSION['cashier_id']=$row[0];
			$_SESSION['first_name']=$row[1];
			$_SESSION['last_name']=$row[2];
			$_SESSION['username']=$row[3];
			header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/cashier.php");
		}else{
			$message;
}
break;
	case 'Manager':
		$result=mysqli_query($con,"SELECT manager_id, first_name,last_name,username FROM manager WHERE username='$username' AND password='$password'");
		$row=mysqli_fetch_array($result);
		if($row>0){
			session_start();
			$_SESSION['manager_id']=$row[0];
			$_SESSION['first_name']=$row[1];
			$_SESSION['last_name']=$row[2];
			$_SESSION['username']=$row[3];
			header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/manager.php");
		}else{
		$message;
	}	
break;
	}

}
?>
<!doctype html>
<html>

	<head>
	   <meta charset="utf-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		<title>Pharmacy Management</title>
		<link rel="icon" href="images/download.PNG" type="image/png"/> <!--adding an icon to tab -->
		<!-- Bootstrap -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<script src="js1/jquery.min.js"></script>
		<script src="js1/bootstrap.min.js"></script>
		<link rel="stylesheet" type="text/css" href="css/styleforP.css"/> <!-- linking stylesheet-->
		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	<style rel="stylesheet" type="text/css">
		.login{
			margin-top:1.3em;
			height:39em;
			box-shadow: 0 .25em .5em 0 rgba(0, 0, 0, 0.5), 0 .375em 1.25em 0 rgba(0, 0, 0, 0.7);
			border-radius:7px;
		}
		.stylef{
			margin-left:6em;
		}
		
		.logPic{
			margin-top:1em;
			height:18em;
			width:100%;
			text-align:center;
		}
		.gstyle{
			width:50%;
			height:inherit;
			box-shadow: 0 .05em .1em  #3479B6; , 0 1em 1em 0 #3479B6;
		

		}
		.input-group{
			width:90%;
			box-shadow: 0 .1em .25em 0 rgba(0, 0, 0, 0.5), 0 .2em .5em 0 rgba(0, 0, 0, 0.7);
		
		}
		.btn{
			width:60%;
		
		}
		.button{
			margin-left:3em !important;
		}
	</style>
	
	</head>
	
	<body id="wrapper" style="background-image:url('');background-repeat:repeat;">
	
		<div class="jumbotron jumbo">
			<h2>Pharmacy Management System</h2> 
		</div>
		
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-4" ></div>
				
				<div class="col-md-4 login" >
				
					<div  >
					
						<div class="logPic "><span class="glyphicon glyphicon-user gstyle img-circle" style="color:#3479B6;font-size:11em;padding-top:.3em;"></span></div>
						
						
						
						
						<div >
							 
							  <?php echo $message; ?>
							  <form class="form-horizontal stylef " role="form" method="POST" action="index.php">
										<br/>
										<div class="form-group input-group">
											<span class="input-group-addon"><span class="glyphicon glyphicon-user "></span>&#32;UserName</span>
											<input type="text" class="form-control" name="username" value=" "/><br />
										</div>
									
										<div class="form-group input-group">
											<span class="input-group-addon"><span class="glyphicon glyphicon-lock "></span>	&#32;PassWord</span>
											<input type="password" class="form-control"  name="password" /><br />
										</div>
									
										<div class="form-group input-group">
										<span class="input-group-addon"><span class="glyphicon glyphicon-ok-circle "></span>&#32;Select Position</span>
											<select class="form-control" name="position" >
												<option readonly > </option>
												<option>Admin</option>
												<option>Pharmacist</option>
												<option>Cashier</option>
												<option>Manager</option>
											</select>
										</div>
										
										<div class="form-group button">
											<input  class="form-group btn btn-primary" type="submit" name="submit" value="Sign In" />
											
										</div>	
							  </form>
						</div>
					
					
					
					</div>
					
				</div>
				
				<div class="col-md-4" ></div>
			
			</div>
		
		
		</div>
	
	
		<div id="footer"></div>
	</body>
	
</html>