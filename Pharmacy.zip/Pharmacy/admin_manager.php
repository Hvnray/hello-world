<?php
session_start();
include_once('connect_db.php');
if(isset($_SESSION['username'])){
	$id=$_SESSION['admin_id'];
	$username=$_SESSION['username'];
}else{
	header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/index.php");
	exit();
}
if(isset($_POST['submit'])){
	$fname=$_POST['first_name'];
	$lname=$_POST['last_name'];
	$postal=$_POST['postal_address'];
	$phone=$_POST['phone'];
	$email=$_POST['email'];
	$user=$_POST['username'];
	$pas=$_POST['password'];
	$sql1=mysqli_query($con, "SELECT * FROM manager WHERE username='$user'")or die(mysqli_error());
	$result=mysqli_num_rows($sql1);
	if($result>0){
		$message="<font color=blue>sorry the username entered already exists</font>";
	}else{
			$sql=mysqli_query($con, "INSERT INTO manager(first_name,last_name,postal_address,phone,email,username,password,date)
			VALUES('$fname','$lname','$postal','$phone','$email','$user','$pas',NOW())");
			if($sql>0) {header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/admin_manager.php");
			}else{
				$message1="<font color=red>Registration Failed, Try again</font>";
				}
		}	
}
if(isset($_POST['update'] ) ){
	$id=$_POST['manager_id'];
	$fname=$_POST['first_name'];
	$lname=$_POST['last_name'];
	$postal=$_POST['postal_address'];
	$phone=$_POST['phone'];
	$email=$_POST['email'];
	$user=$_POST['username'];
	$pas=$_POST['password'];
	// get value of id that sent from address bar
	
 
	// Retrieve data from database 
		$sqlUpdate="UPDATE manager SET first_name='$fname', last_name='$lname',postal_address='$postal',phone='$phone',email='$email',username='$user', password='$pas' WHERE manager_id='$id'";

		$update = $con->prepare($sqlUpdate);
		if($update->execute()){
			$pharmUpdateError='<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a> <strong>Update Successful!</strong></div>';
			
		}else{
			$pharmUpdateError='<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a> <strong>Update Failed!</strong></div>';
		}
	
}

	
?>


<!doctype html>
<html lang="en-US">

	<head>
	   <meta charset="utf-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		<title>Pharmacy Management</title>
		<link rel="icon" href="images/download.PNG" type="image/png"/> <!--adding an icon to tab -->
		<!-- Bootstrap -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<script src="js1/jquery.min.js"></script>
		<script src="js1/bootstrap.min.js"></script>
		<link rel="stylesheet" type="text/css" href="css/styleforP.css"/> <!-- linking stylesheet-->
		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	
	
	</head>
	
	<body id="wrapper">
	
		<div class="jumbotron jumbo">
			<h2>Pharmacy Management System</h2> 
		</div>
		
		<div class="container-fluid stoppad">
			<div class="row">
			<div class="col-md-2 sidenav">
				<ul class="nav nav-pills nav-stacked">
					<li><a href="admin.php">Dashboard</a></li>
					<li><a href="admin_pharmacist.php">Pharmacist</a></li>
					<li class="active"><a href="admin_manager.php">Manager</a></li>
					<li><a href="admin_cashier.php">Cashier</a></li>
					<li><a href="logout.php">Log out</a></li>
				</ul>
			</div>
			
			<div class="col-md-10">
				<h3 class="manage">Manage Managers</h3>
			<hr>
				<div class="container-fluid">
					  <ul class="nav nav-tabs">
						<li class="active"><a data-toggle="tab" href="#view">View Managers</a></li>
						<li><a data-toggle="tab" href="#add">Add Managers</a></li>
					</ul>
					
					<div class="tab-content">
					
					
						<div id="view" class="tab-pane fade in active">
						<?php echo $pharmUpdateError;?>
						<?php echo $message;
							  echo $message1;
							/*View Displays all data from 'manager' table*/
							// connect to the database
								include_once('connect_db.php');
									// get results from database
							$result = $con->query("SELECT * FROM manager");
								// display data in table
								
							echo "<table class='table table-striped'>
							
								<thead>
									<tr>  <th>Firstname</th> <th>Lastname</th><th>Username </th><th>Phone Number</th><th>Email</th><th>Update </th><th>Delete</th> </tr>
								</thead>"; 
								        // loop through results of database query, displaying them in the table
								while($row = mysqli_fetch_array( $result )) {
								// echo out the contents of each row into a table
								echo "<tbody>";
								echo "<tr>";
								//echo '<td>' . $row['pharmacist_id'] . '</td>';
								echo '<td>' . $row['first_name'] . '</td>';
								echo '<td>' . $row['last_name'] . '</td>';
								echo '<td>' . $row['username'] . '</td>';
								echo '<td>' . $row['phone'] . '</td>';
								echo '<td>' . $row['email'] . '</td>';
								?>
								<td><a data-toggle="modal" class="update-det" href="#pharmacyupdate" data-id="<?php echo $row['manager_id'] ?>"> <span class="glyphicon glyphicon-wrench"></span></a></td>
								<td><a href="delete_manager.php?manager_id=<?php echo $row['manager_id']?>"><span class="glyphicon glyphicon-remove"style="color:red;"></span></a></td>
								<?php
								}
								echo "</tbody>";
								echo "</table>";
							?>
						</div>
						
						<div id="add" class="tab-pane fade">
						<!--Pharmacist-->
								<?php echo $message;
								echo $message1;
								?>
							<form class="form form-horizontal" role="form" name="form1" action="admin_manager.php" method="POST" >
							
								<div class="form-group">
									<label class="control-label col-sm-2" for="First name">First Name:</label>
									<div class="col-sm-10">
									<input class="form-control" name="first_name" type="text"  placeholder="First Name" required id="first_name" />
									</div>
								</div>

								<div class="form-group">
									<label class="control-label col-sm-2" for="Last name">Last Name:</label>
									<div class="col-sm-10">
									<input class="form-control" name="last_name" type="text"  placeholder="Last Name" required id="last_name" />
									</div>
								</div>

								<div class="form-group">
									<label class="control-label col-sm-2" for="username">Username:</label>
									<div class="col-sm-10">
									<input class="form-control" name="username" type="text"  placeholder="Username" required id="username" />
									</div>
									
								</div>

								<div class="form-group">
									<label class="control-label col-sm-2" for="address">Address:</label>
									<div class="col-sm-10">
									<input class="form-control" name="postal_address" type="text"  placeholder="Address" required id="postal_address" />
									</div>
								</div>

								<div class="form-group">
									<label class="control-label col-sm-2" for="phone number">Phone Number:</label>
									<div class="col-sm-10">
									<input class="form-control" name="phone" type="tel" placeholder="Phone"  required id="phone" />  
									</div>
								</div>

								<div class="form-group">
									<label class="control-label col-sm-2" for="email">Email:</label>
									<div class="col-sm-10">
									<input class="form-control" name="email" type="email" placeholder="Email" required id="email" /> 
									</div>
								</div>

							
								<div class="form-group">
									<label class="control-label col-sm-2" for="password">Password:</label>
									<div class="col-sm-10">
									<input class="form-control" name="password" type="password"  placeholder="Password" required id="password"/>
									</div>
								</div>								
								
								<div class="col-sm-2"></div>
								<div class="col-sm-offset-2 col-sm-6">
								<button class="btn btn-primary btn-block btn-lg" name="submit" type="submit" >submit</button>
								</div>
							</form>
						
						
						</div>
						
						
					</div>
				
				</div>
			</div>
			</div>
			
			
			
		</div>
		
		
		
		<!--                                -->
		
			
		<!-- Modal -->
		<div id="pharmacyupdate" class="modal fade" role="dialog">
			<div class="modal-dialog">

				<!-- Modal content-->
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h2 class="modal-title">Update Managers</h2>
					</div>
					<div class="modal-body">
					
						<form class="form form-horizontal update-form" role="form" name="myform"  method="POST" >
							<div class="fetched-data"></div>
							
							
							<input type="hidden" name="manager_id" readonly >
							<div class="form-group">
									<label class="control-label col-sm-3" for="First name">First Name:</label>
									<div class="col-sm-9">
									<input class="form-control" name="first_name" type="text" placeholder="First Name" value="<?php echo $_GET['first_name']?>" id="first_name1" />
									</div>
							</div>

							<div class="form-group">
									<label class="control-label col-sm-3" for="last name">Lastname Name:</label>
									<div class="col-sm-9">
									<input class="form-control" name="last_name" type="text" placeholder="Last Name" id="last_name1" value="<?php echo $_GET['last_name']?>" />
									</div>
							</div>

							<div class="form-group">
									<label class="control-label col-sm-3" for="Address">Address:</label>
									<div class="col-sm-9">
									<input class="form-control" name="postal_address" type="text" placeholder="Address" id="postal_address1" value="<?php echo $_GET['postal_address']?>" /> 
									</div>
							</div>

							<div class="form-group">
									<label class="control-label col-sm-3" for="Phone Number">Phone Number:</label>
									<div class="col-sm-9">
									<input class="form-control" name="phone" type="text" placeholder="Phone" id="phone1" value="<?php  echo $_GET['phone']?>" />
									</div>
							</div>

							<div class="form-group">
									<label class="control-label col-sm-3" for="Email">Email:</label>
									<div class="col-sm-9">
									<input class="form-control" name="email" type="email"placeholder="Email" id="email1"value="<?php echo $_GET['email']?>" />
									</div>
							</div>

							<div class="form-group">
									<label class="control-label col-sm-3" for="user name">User Name:</label>
									<div class="col-sm-9">
									<input class="form-control" name="username" type="text"  placeholder="Username" id="username1"value="<?php echo $_GET['username']?>" />
									</div>
							</div>

							<div class="form-group">
									<label class="control-label col-sm-3" for="First name">password:</label>
									<div class="col-sm-9">
									<input class="form-control" name="password" placeholder="Password" id="password1"value="<?php echo $_GET['password']?>"type="password" />
									</div>
							</div>

							<div class="col-sm-3"></div>
							<div class="col-sm-offset-1 col-sm-7">
								<button class="btn btn-primary btn-block" name="update" type="submit">Update</button>
							</div>	
						</form>
					</div>
					<br><br>
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				</div>

			</div>
		</div>
		
		<div id="footer">
		
			</div>
	</body>
	
	<script type="text/javascript">

		$(".update-det").click(function(){
			var userID = $(this).attr("data-id");
			$.ajax({
				type : 'post',
				url : 'fetch_record.php', //Here you will fetch records 
				data :  {manager_id : userID}, //Pass $id
				success : function(data){
										
					var details = JSON.parse(data);
					
					$('.update-form input[name="manager_id"]').val(details['manager_id']);
					$('.update-form input[name="first_name"]').val(details['first_name']);
					$('.update-form input[name="last_name"]').val(details['last_name']);
					$('.update-form input[name="postal_address"]').val(details['postal_address']);
					$('.update-form input[name="email"]').val(details['email']);
					$('.update-form input[name="username"]').val(details['username']);
					$('.update-form input[name="password"]').val(details['password']);
					$('.update-form input[name="phone"]').val(details['phone']);
					//$('.fetched-data').html(data);//Show fetched data from database
				}
			});
		});
	</script>
	
</html>